// Main JS (shared across all pages)
// can put common features like dark mode, nav menu, etc.
console.log("Main JS loaded");



